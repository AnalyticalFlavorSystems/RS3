#' RS3.
#'
#' @name RS3
#' @docType package
#' @useDynLib RS3
#' @importFrom Rcpp evalCpp

NULL
