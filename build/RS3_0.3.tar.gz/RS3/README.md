RS3 is a interface to S3 using libs3.  Using RS3 you can do many tasks including:

* Create/delete a bucket
* upload/download a file
* set-acl on bucket
* get/set-logging on bucket

It currently does not work with Windows.  It is a work in progress.  
In order to use RS3 you must make sure the libs3 library is installed.  The library is located [here](https://aws.amazon.com/developertools/1648).

